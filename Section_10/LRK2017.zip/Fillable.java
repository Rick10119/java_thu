public interface Fillable {

    public abstract void howToFill();

}
